import React, {useEffect, useState} from 'react'; 
import {useParams} from 'react-router-dom'
import axios from 'axios'

const OneProduct = (props) => {
    const [product, setProduct] = useState({})//object bc it just returns one thing and not an array bc it doesnt return many things
    const {id} = useParams()
    console.log(id)
    useEffect(()=>{
        axios.get(`http://localhost:8000/api/oneProduct/${id}`)
        .then((res) => {//if succesfull..
            console.log(res.data);
            setProduct(res.data)
        })
        .catch((err) => {//if error..
            console.log(err);
        })
    },[])
    return(
        <div>
            <h1>Title: {product.title}</h1> 
            <h2>Price: ${product.price} </h2>
            <h2>Description: {product.description}</h2>
        </div>
    )
}

export default OneProduct;