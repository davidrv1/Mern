import axios from 'axios'; 
import {useEffect, useState} from 'react'
import {Link} from 'react-router-dom'

const Display = (props) => {
    const [allProducts, setAllProducts] = useState([])
    useEffect(() => {
        axios.get('http://localhost:8000/api/allProducts')
        .then((response) => {
            console.log(response);
            setAllProducts(response.data)
        })
        .catch((err) => {//if error..
            console.log(err);
        })
        }, [])

    const deleteHanlder = (id) => {
        console.log(id);
        axios.delete(`http://localhost:8000/api/deleteProduct/${id}`)
            .then((res) => {//if succesful..
                console.log(res);
                const updatedProductList = allProducts.filter((product) => product._id !== id)
                //
                setAllProducts(updatedProductList)//
            })
            .catch((err) => {//if error..
                console.log(err);
            })
    }
    return (
        <div>
            <h2>Product Manager</h2>
            {
                allProducts.map((product) => (
                    <div key={product._id}>
                        <h2>Title: {product.title}</h2> 
                        <h2>Price: {product.price}</h2>
                        <h2>Description: {product.description}</h2>
                        <Link to={`/oneProduct/${product._id}`}>View</Link>
                        <br/>
                        <Link to={`/editProduct/${product._id}`}>Edit</Link>
                        <button onClick={() => deleteHanlder(product._id)}>Delete</button>
                    </div>
                ))
            }
        </div>
    )
}

export default Display;